package web;

import entities.Salesman;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import repositories.SalesmanRepository;

import static org.hamcrest.Matchers.hasItem;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import javax.swing.text.View;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static org.hamcrest.Matchers.hasSize;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import static org.junit.jupiter.api.Assertions.*;

class SalesmanControllerTest {

    Salesman salesman;
    private MockMvc mockMvc;
    @Mock
    SalesmanRepository salesmanRepository;

    @Mock
    View mockView;

    @InjectMocks
    SalesmanController salesmanController;
    @Test
    void salesman()throws ParseException {

        // Cria um objeto de estudante com dados fictícios
        salesman = new Salesman();
        salesman.setId(1L);
        salesman.setName("John");

        String sDate1 = "2012/11/11";
        Date date1 = new SimpleDateFormat("yyyy/MM/dd").parse(sDate1);
        salesman.setDot(date1);
        salesman.setItem("Washing Machine");
        salesman.setAmount(5000);

        MockitoAnnotations.openMocks(this);

        // Inicializa o MockMvc para testar o controlador de forma isolada
        mockMvc = MockMvcBuilders.standaloneSetup(salesmanController).build();
    }

    @Test
    public void findAll_ListView() throws Exception {
        // Lista fictícia de estudantes
        List<Salesman>list=new ArrayList<Salesman>();
        list.add(salesman);
        list.add(salesman);

        // Configura o comportamento simulado do repositório
        when(salesmanRepository.findAll()).thenReturn(list);

        // Realiza uma solicitação HTTP GET para /index e verifica o resultado
        mockMvc.perform(get("/index"))
                .andExpect(status().isOk())
                .andExpect(model().attribute("listStudents", list))
                .andExpect(view().name("students"))
                .andExpect(model().attribute("listStudents", hasSize(2)));

        // Verifica se o método findAll do repositório foi chamado corretamente
        verify(salesmanRepository, times(1)).findAll();
        verifyNoMoreInteractions(salesmanRepository);
    }    @Test
    void delete() {
        ArgumentCaptor<Long> idCapture = ArgumentCaptor.forClass(Long.class);
        doNothing().when(salesmanRepository).deleteById(idCapture.capture());
        salesmanRepository.deleteById(1L);
        assertEquals(1L, idCapture.getValue());
        verify(salesmanRepository, times(1)).deleteById(1L);
    }
    @Test
    void findById() throws Exception {

        List<Salesman> list = new ArrayList<Salesman>();
        list.add(salesman);
        when(salesmanRepository.findSalesmanById(1L)).thenReturn(list);
        mockMvc.perform(get("/index").param("keyword", "1"))
                .andExpect(status().isOk())
                .andExpect(model().attribute("listStudents", hasItem(salesman)))
                .andExpect(view().name("students"))
                .andExpect(model().attribute("listStudents", hasSize(1)));

        verify(salesmanRepository, times(1)).findSalesmanById(anyLong());
        verifyNoMoreInteractions(salesmanRepository);
    }
    @Test
    void formStudents() {
        try {
            mockMvc.perform(get("/salesman"))
                    .andExpect(status().isOk())
                    .andExpect(model().attribute("student", new Salesman()))
                    .andExpect(view().name("formStudents"));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Test
    void save() {
        // Configura o comportamento simulado do repositório
        when(salesmanRepository.save(salesman)).thenReturn(salesman);

        // Chama o método save e verifica se o repositório save foi chamado
        salesmanRepository.save(salesman);
        verify(salesmanRepository, times(1)).save(salesman);
    }

    @Test
    void editSalesman() {
    }
}
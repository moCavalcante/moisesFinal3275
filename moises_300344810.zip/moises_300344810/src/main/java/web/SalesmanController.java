package web;

import entities.Salesman;
import jakarta.servlet.http.HttpSession;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import repositories.SalesmanRepository;

import java.util.Arrays;
import java.util.List;

@Controller
@AllArgsConstructor
public class SalesmanController {

    @Autowired
    private SalesmanRepository salesmanRepository;

    public String itemType;
    private int num =0;

//git@github.com:moCavalcante/moisesFinal3275.git
    @GetMapping(path="/index")
    public String salesman(Model model, @RequestParam(name="keyword",defaultValue="")String keyword){

        List<Salesman> salesman ;
        if (keyword.isEmpty()){
          salesman  = salesmanRepository.findAll();
        }
        else{
            long key = Long.parseLong(keyword);
            salesman  = salesmanRepository.findSalesmanById(key);
        }
        model.addAttribute("listSalesman",salesman);
        return "salesman";
    }
    @RequestMapping(value = "/populateProducts", method = RequestMethod.GET)
    public String populateItemList(Model model) {
        List<String> itemList = Arrays.asList("Washing Machine", "Refrigerator", "Music System");

        if (num >= 0 && num < itemList.size()) {
            itemType = itemList.get(num);
        }

        model.addAttribute("products", itemList);
        return "redirect:/index";
    }
    @GetMapping("/delete")
    public String delete(Long id, ModelMap mm) {
        salesmanRepository.deleteById(id);
        mm.put("a", 0);
        mm.put("e", 0);
        return "redirect:/index";
    }
    @GetMapping("/salesman")
    public String formSalesman(Model model) {
        model.addAttribute("student", new Salesman());
        return "salesman";
    }

    @PostMapping(path = "/save")
    public String save(Model model, Salesman student, BindingResult bindingResult, ModelMap mm, HttpSession session) {

        if (bindingResult.hasErrors()) {
            return "redirect:/index";
        } else {
            salesmanRepository.save(student);

            if (num == 2) {
                mm.put("e", 2);
                mm.put("a", 0);
            } else {
                mm.put("a", 1);
                mm.put("e", 0);
            }
            return "redirect:index";
        }
    }
    @GetMapping("/editSalesView")
    public String editSalesman(Model model, Long id, HttpSession session) {
        num = 2;
        session.setAttribute("info", 0);
        Salesman salesman = salesmanRepository.findById(id).orElse(null);
        if (salesman == null) throw new RuntimeException("Salesman does not exist");
        model.addAttribute("salesman", salesman);
        return "editSalesView";
    }

}

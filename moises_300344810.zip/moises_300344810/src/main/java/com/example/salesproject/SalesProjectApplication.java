package com.example.salesproject;

import entities.Salesman;
import repositories.SalesmanRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.Date;
@SpringBootApplication
public class SalesProjectApplication {

	public static void main(String[] args) {
		//git@github.com:moCavalcante/moisesFinal3275.git

		SpringApplication.run(SalesProjectApplication.class, args);
	}


}
